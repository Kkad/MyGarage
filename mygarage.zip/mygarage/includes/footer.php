 <!-- Footer -->
 
	    <div class="footer">
	    	<div class="container">
			
		    	<div class="row">
				
		    		<div class="col-footer col-md-4 col-xs-6">
		    			<h3>Contact Us</h3>
		    			<p class="contact-us-details">
	        				<b>Address:</b> Tashkent Uzbekistan<br/>
	        				<b>Phone:</b> (+998) 97 170 70 70<br/>
	        	
	        				<b>Email:</b> <a href="#">Cars@mygarage.uz</a>
	        			</p>
		    		</div>				
		    		<div class="col-footer col-md-4 col-xs-6">
		    			<h3>Our Social Networks</h3>
						<p>You can find us on facebook and other social websites</p>
		    			<div>
		    				<img src="./img/icons/facebook.png" width="32" alt="Facebook">
		    				<img src="./img/icons/twitter.png" width="32" alt="Twitter">
		    				<img src="./img/icons/linkedin.png" width="32" alt="LinkedIn">
							<img src="./img/icons/rss.png" width="32" alt="RSS Feed">
						</div>
		    		</div>
		    		<div class="col-footer col-md-4 col-xs-6">
		    			<h3>About Us</h3>
		    				<p>This website is created by IUT students for Internet Programming class project </p>
		    		</div>

		    	</div>
		    	<div class="row">
		    		<div class="col-md-12">
		    			<div class="footer-copyright">&copy; 2017 <a href="index.php">MyGarage</a> </div>
		    		</div>
		    	</div>
		    </div>
	    </div>

        